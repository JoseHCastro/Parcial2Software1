#/controllers/estudiante_controller.py
from odoo import http
from odoo.http import request

class EstudianteController(http.Controller):
    @http.route('/api/estudiantes', auth='public', methods=['GET'], type='json')
    def get_estudiantes(self, **kwargs):
        estudiantes = request.env['agenda.estudiante'].sudo().search([])
        data = []
        for estudiante in estudiantes:
            data.append({
                'id': estudiante.id,
                'name': estudiante.name,
                'apellido': estudiante.apellido,  # Asegúrate de que este campo exista
                'edad': estudiante.edad,  # Asegúrate de que este campo exista
                'grado': estudiante.grado,  # Asegúrate de que este campo exista
                'email': estudiante.email,
            })
        return data
